import { defineConfig } from 'vite';
export default defineConfig({server:{proxy:{'/api':'http://127.0.0.1:3000','/review':'http://127.0.0.1:3000'}}});
